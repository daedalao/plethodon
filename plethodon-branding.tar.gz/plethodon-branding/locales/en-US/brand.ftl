# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.

## SiskiyouPlethodon brand (see branding/NAMING.md in the project repo).
## Independent build from Mozilla Firefox source code; not a Mozilla product,
## so the Firefox name appears only in the attribution line below.

-brand-shorter-name = Plethodon
-brand-short-name = Plethodon
-brand-shortcut-name = Plethodon
-brand-full-name = SiskiyouPlethodon
# This brand name can be used in messages where the product name needs to
# remain unchanged across different versions.
-brand-product-name = SiskiyouPlethodon
-vendor-short-name = Mozilla
trademarkInfo = Built from Mozilla Firefox 154.0.1 source code for Arch POWER (powerpc). Not affiliated with or endorsed by Mozilla.
